export interface Shoplist {
    ShopID: number;
    ShopTitle: string;
    Address: string;
    Latitude: number;
    Longitude: number;
    name:string;
  }



## Smart Sales Monitoring App

![alt text](http://s3.amazonaws.com/creativetim_bucket/products/53/original/opt_md_angular_thumbnail.jpg "Material Dashboard Angular Free")

## Objective
The objectives of sales monitoring system are to provide the desired level of service, also inspecting real time data, and to minimize the human effort.

## Introduction
A sales and inventory monitoring system collect data to aid in production scheduling. The application will help in decision making using past data. All data populated on Google map using clustering API. it’s totally different from traditional sales monitoring system.

## Problem Description
Management now-a-days are more concerned about data comparison. Such problem face by every organization our application provides complete solution.

## Methodology
Web Application will be built using real time data, includes monitoring the levels of a product at all locations. Moreover, provide current status of shops transaction. 


## Feature Set
1. Productive Shop Information
2. Online Shops Locations
3. Data Monitoring
4. Data Comparison
5. Google Map Clustering
6. Google Map Route


## Evaluation Criteria
Random sales of various shops shall be performed to check output of the application accordingly.

## Project Scope
Project is targeted for Sales specially when they are linked     with Distributor representative or want to take Decision regarding Upcoming business strategy.

## Resource Requirement (HW / SW)
1. Android Mobile and Application.
2. Web Application.
3. Tools/Technologies
4. Android Studio.
5. Visual Studio Code.
6. Google Firebase.









export class AppSettings {
    public static API_BASE_URL  = 'http://localhost:5000/api/';
    public static USER_INFORMATION_URL  = 'UserInformation';
    public static AUTH_REGISTER_URL = 'Auth/register';
    public static AUTH_UPDATE_USER_URL = 'Auth/updateuser';
    public static AUTH_LOGIN_URL = 'Auth/login';
}

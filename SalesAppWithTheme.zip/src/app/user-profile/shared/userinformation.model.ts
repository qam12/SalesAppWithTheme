export class Userinformation {
    Id: Number;
    Name: String;
    LoginUserName: String;
    Email: String;
    Phone: String;
    Password: String;
    EntryTime: Date;
    IsActive: boolean;
    IsDeleted: boolean;
    CompanyId: Number;
    OfficeId: Number;
    UserRoleId: Number;
    CompanyName: String;
    OfficeName: String;
    UserRoleName: String;
}

export class Login {
    Username: string;
    Password: string;
}

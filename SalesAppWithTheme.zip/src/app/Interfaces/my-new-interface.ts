export interface MyNewInterface {
    ActivityDate: Date;
    ActivityTime: string;
    Address: string;
    DSRID:number;
    DSRTitle:string;
    DistributorAddress:string;
    DistributorCode:number;
    DistributorID:number;
    DistributorTitle:string;
    DistributroRefNo:string;
    GoogleAddress:string;
    Latitude :number;
    Longtitude:number;
    ShopID:number;
    ShopTitle: string;
    UserID: number;
    UserName:string;

}

export interface ShopList {
    ShopID: number;
    ShopTitle: string;
    Address: string;
    Latitude: number;
    Longitude: number;
  }
